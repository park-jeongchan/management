package lecture13;

public class Member {

	String id,pass,name;
	int sortation;
	
	public Member(String id, String pass, String name, int sortation) {
		super();
		this.id = id;
		this.pass = pass;
		this.name = name;
		this.sortation = sortation;
	}

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getPass() {
		return pass;
	}

	public void setPass(String pass) {
		this.pass = pass;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public int getSortation() {
		return sortation;
	}

	public void setSortation(int sortation) {
		this.sortation = sortation;
	}

	@Override
	public String toString() {
		return "Member [id=" + id + ", pass=" + pass + ", name=" + name + ", sortation=" + sortation + "]";
	}
	
	
}
