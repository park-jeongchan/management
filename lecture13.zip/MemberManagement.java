package lecture13;

import java.io.DataInputStream;

import java.io.DataOutputStream;
import java.io.EOFException;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.InputMismatchException;
import java.util.Scanner;
import java.util.Base64;
import java.util.Base64.Decoder;
import java.util.Base64.Encoder;

import javax.crypto.Cipher;
import javax.crypto.spec.IvParameterSpec;
import javax.crypto.spec.SecretKeySpec;
import lecture10.*;



public class MemberManagement {
	static ArrayList<Member> members = new ArrayList<Member>();
	JavaEnCryto en=new JavaEnCryto();
	Scanner sc = null;

	public MemberManagement() {
		sc = new Scanner(System.in);
	}

	public ArrayList<Member> login(String filePath) {
		Member m = null;
		ArrayList<Member> member = new ArrayList<Member>();
		
		try {
			DataInputStream in = new DataInputStream(new FileInputStream(filePath));
			String id, pass, name;
			int sortation;
			boolean EOF = false;

			while (!EOF) {
				try {
					while (true) {
						id = in.readUTF();
						in.readChar();
						pass=in.readUTF();
						in.readChar();
						name = in.readUTF();
						in.readChar();
						sortation = in.readInt();
						in.readChar();
						m = new Member(id, pass, name, sortation);
						member.add(m);
					}

				} catch (EOFException e) {
					EOF = true;
				} catch (Exception e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
	
				in.close();
			}
		} catch (FileNotFoundException e) {
			System.out.println("FileNotFoundException");
		} catch (IOException e) {
			System.out.println("IOException");
		}
		return member;
	}

	public int loginMenu(String filePath) {
		members = login("members.txt");
		for (int i = 0; i < members.size(); i++) {
			System.out.println(members.get(i).toString());
		}
		int num = 0;
		String id0;
		String pass0;
		while (num != 1) {
			System.out.print("id:");
			id0 = sc.next();
			System.out.print("password:");
			pass0 = sc.next();
			for (int i = 0; i < members.size(); i++) {
				if (id0.equals(members.get(i).getId())) {
					if (pass0.equals(members.get(i).getPass())) {
						num=1;
						return members.get(i).getSortation();
					} 
				}
			}
			System.out.println("�ٽ� �õ�");
		}
		return -1;
	}
	

	public void viewMenu() {
		System.out.println("1.�ű� ȸ������");
		System.out.println("2.ȸ������ ����");
		System.out.println("3.ȸ�� ����");
		System.out.println("4.ȸ������ ����");
		System.out.println("5.���� ȭ������");
		System.out.println("0.����");
	}

	public void selectMenu() {
		viewMenu();
		int num = -1;
		while (num != 5) {
			try {
				System.out.print("�޴� ����:");
				num = sc.nextInt();
				switch (num) {
				case 1:
					members.add(registerMember());
					break;
				case 2:reviseMember();
					break;
				case 3:removeMember();
					break;
				case 4:viewMember();
					break;
				case 5:
					writeMember(members, "members.txt");
					break;
				
				}
			} catch (InputMismatchException e) {
				System.out.println("������ �Է��ϼ���");
				sc.next();
				continue;
			} catch (NullPointerException e) {
				System.out.println("null���� �ֽ��ϴ�.");
				continue;
			}
		}
	}

	public Member registerMember() {
		Member m = null;
		try {
			System.out.print("id:");
			String id = sc.next();
			System.out.print("pass:");
			String pass = sc.next();
			String passEn=en.Encrypt(pass, "key");
			System.out.print("name:");
			String name = sc.next();
			System.out.print("sortation:");
			int sortation = sc.nextInt();
			m = new Member(id, passEn, name, sortation);
		} catch (InputMismatchException e) {
			throw e;
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return m;
	}

	public void writeMember(ArrayList<Member> members, String filePath) {
		DataOutputStream fout = null;
		JavaEnCryto de=new JavaEnCryto();
		String passDe;
		try {
			fout = new DataOutputStream(new FileOutputStream(filePath));
			for (int i = 0; i < members.size(); i++) {
				fout.writeUTF(members.get(i).getId());
				fout.writeChar('\t');
				fout.writeUTF(en.Decrypt(members.get(i).getPass(),"key"));
				fout.writeChar('\t');
				fout.writeUTF(members.get(i).getName());
				fout.writeChar('\t');
				fout.writeInt(members.get(i).getSortation());
				fout.writeChar('\n');
			}
		} catch (Exception e) {
			System.out.println("Exeption");
		}
		
	}

	public void removeMember() {
		String searcher;
		System.out.print("������ ����� id");
		searcher=sc.next();
		for(int i=0;i<members.size();i++) {
			if(searcher.equals(members.get(i).getId())) {
				members.remove(i);
				System.out.print(searcher+"�� ���� �Ǿ����ϴ�");
			}
		}
	}
	
	public void reviseMember() {
		System.out.print("������ ����� id:");
		String searcher=sc.next();
		System.out.print("1.pass ���� 2.�̸� ���� 0.����");
		int num=sc.nextInt();
		if(num==1) {
			for(int i=0;i<members.size();i++) {
				if(searcher.equals(members.get(i).getId())) {
					System.out.print("������ pass:");
					String pass1=sc.next();
					System.out.print("�ٽ� �ѹ� �Է�:");
					String pass2=sc.next();
					if(pass1.equals(pass2)) {
						members.get(i).setPass(pass1);
					}
					else {
						System.out.println("�� �Է°��� Ʋ���ϴ�.");
						i--;
					}
				}
			}
			
		}else if(num==2) {
			for(int i=0;i<members.size();i++) {
				if(searcher.equals(members.get(i).getId())) {
					members.get(i).setName(sc.next());
				}
			}
		}else {
			System.out.print("�����մϴ�.");
		}
		
	}
	
	public void viewMember()  {
		for (int i = 0; i < members.size(); i++) {
				System.out.println(members.get(i).toString());
			}
		}
	
	
	public static void main(String args[]) {
		MemberManagement run = new MemberManagement();
		run.selectMenu();
	}

}
